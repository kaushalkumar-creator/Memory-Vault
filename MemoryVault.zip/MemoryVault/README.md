# Memory Vault

Keep the things worth remembering.

## Build on GitHub (no PC needed)
1. Upload this project to a GitHub repository.
2. Open the Actions tab, select "Build Debug APK", and run it (or push a commit).
3. Download the `memory-vault-debug-apk` artifact from the finished run.
