package com.kaushal.memoryvault.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF171717)
val Paper = Color(0xFFF7F7F5)
val Muted = Color(0xFF707070)
val SoftGray = Color(0xFFF0F0EE)
val Lavender = Color(0xFFEDE7FF)
val CardWhite = Color(0xFFFFFFFF)

private val MemoryVaultScheme = lightColorScheme(
    primary = Ink,
    onPrimary = CardWhite,
    background = Paper,
    onBackground = Ink,
    surface = CardWhite,
    onSurface = Ink,
    secondaryContainer = Lavender,
    onSecondaryContainer = Ink,
    surfaceVariant = SoftGray,
    onSurfaceVariant = Muted
)

@Composable
fun MemoryVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MemoryVaultScheme, content = content)
}
