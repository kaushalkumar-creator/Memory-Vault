package com.kaushal.memoryvault

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaushal.memoryvault.data.Memory
import com.kaushal.memoryvault.data.MemoryType
import com.kaushal.memoryvault.data.MemoryViewModel
import com.kaushal.memoryvault.ui.CardWhite
import com.kaushal.memoryvault.ui.HomeScreen
import com.kaushal.memoryvault.ui.LibraryScreen
import com.kaushal.memoryvault.ui.MemoryDetailDialog
import com.kaushal.memoryvault.ui.MemoryFormScreen
import com.kaushal.memoryvault.ui.MemoryVaultTheme
import com.kaushal.memoryvault.ui.ProfileScreen
import com.kaushal.memoryvault.ui.SavedScreen
import com.kaushal.memoryvault.ui.SearchScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        setTheme(R.style.Theme_MemoryVault_Main)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MemoryVaultTheme {
                MemoryVaultApp()
            }
        }
    }
}

@Composable
fun MemoryVaultApp(vm: MemoryViewModel = viewModel()) {
    val memories by vm.memories.collectAsState()
    val recent by vm.recentSearches.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var formType by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedId by rememberSaveable { mutableLongStateOf(-1L) }
    val context = LocalContext.current

    val currentForm = formType
    val selected = memories.find { it.id == selectedId }
    val labels = listOf("Home", "Library", "Saved", "Profile")
    val icons = listOf(Icons.Filled.Home, Icons.Filled.GridView, Icons.Filled.Favorite, Icons.Filled.Person)

    when {
        showSearch -> SearchScreen(
            memories = memories,
            recent = recent,
            onAddSearch = vm::addSearch,
            onOpen = { selectedId = it.id },
            onBack = { showSearch = false }
        )

        currentForm != null -> MemoryFormScreen(
            type = currentForm,
            onBack = { formType = null },
            onSave = {
                vm.save(it)
                formType = null
            }
        )

        else -> Scaffold(
            bottomBar = {
                NavigationBar(containerColor = CardWhite) {
                    labels.forEachIndexed { i, label ->
                        val scale by animateFloatAsState(if (tab == i) 1.08f else 1f, label = "tabScale")
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                Icon(
                                    icons[i],
                                    contentDescription = label,
                                    modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                                )
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> HomeScreen(
                        memories = memories,
                        onSearch = { showSearch = true },
                        onSeeAll = { tab = 1 },
                        onOpen = { selectedId = it.id }
                    )
                    1 -> LibraryScreen(onCreate = { formType = it })
                    2 -> SavedScreen(
                        memories = memories.filter { it.saved },
                        onOpen = { selectedId = it.id }
                    )
                    else -> ProfileScreen(
                        total = memories.size,
                        saved = memories.count { it.saved }
                    )
                }
            }
        }
    }

    selected?.let { memory ->
        MemoryDetailDialog(
            memory = memory,
            onDismiss = { selectedId = -1L },
            onToggleSave = { vm.toggleSaved(memory) },
            onDelete = {
                vm.delete(memory)
                selectedId = -1L
            },
            onOpenMedia = { openMedia(context, memory) }
        )
    }
}

private fun openMedia(context: Context, memory: Memory) {
    val raw = memory.mediaUri ?: return
    try {
        val uri = Uri.parse(raw)
        val fallback = if (memory.type == MemoryType.VIDEO) "video/*" else "image/*"
        val mime = context.contentResolver.getType(uri) ?: fallback
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No app found to open this file.", Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        Toast.makeText(context, "This file is no longer accessible.", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open this file.", Toast.LENGTH_SHORT).show()
    }
}
