package com.kaushal.memoryvault.data

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MemoryViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = MemoryDatabase.get(app).memoryDao()
    private val prefs = app.getSharedPreferences("memory_vault_prefs", Context.MODE_PRIVATE)

    val memories: StateFlow<List<Memory>> =
        dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _recentSearches = MutableStateFlow(loadSearches())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    fun save(memory: Memory) {
        viewModelScope.launch { dao.insert(memory) }
    }

    fun toggleSaved(memory: Memory) {
        viewModelScope.launch { dao.update(memory.copy(saved = !memory.saved)) }
    }

    fun delete(memory: Memory) {
        viewModelScope.launch { dao.delete(memory) }
    }

    fun addSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val updated = (listOf(q) + _recentSearches.value.filterNot { it.equals(q, ignoreCase = true) }).take(8)
        _recentSearches.value = updated
        prefs.edit().putString(KEY_SEARCHES, updated.joinToString(SEPARATOR)).apply()
    }

    private fun loadSearches(): List<String> =
        prefs.getString(KEY_SEARCHES, "").orEmpty().split(SEPARATOR).filter { it.isNotBlank() }

    companion object {
        private const val KEY_SEARCHES = "recent_searches"
        private const val SEPARATOR = "\u001F"
    }
}
