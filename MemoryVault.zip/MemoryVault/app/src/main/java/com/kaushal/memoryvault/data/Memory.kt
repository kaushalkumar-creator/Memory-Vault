package com.kaushal.memoryvault.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

object MemoryType {
    const val PROMPT = "PROMPT"
    const val PHOTO = "PHOTO"
    const val VIDEO = "VIDEO"
    const val EVENT = "EVENT"

    fun label(type: String): String = when (type) {
        PROMPT -> "Prompt"
        PHOTO -> "Photo"
        VIDEO -> "Video"
        else -> "Event"
    }
}

@Entity(tableName = "memories")
data class Memory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val title: String,
    val description: String = "",
    val mediaUri: String? = null,
    val eventDate: String = "",
    val eventTime: String = "",
    val saved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun all(): Flow<List<Memory>>

    @Insert
    suspend fun insert(memory: Memory): Long

    @Update
    suspend fun update(memory: Memory)

    @Delete
    suspend fun delete(memory: Memory)
}

@Database(entities = [Memory::class], version = 1, exportSchema = false)
abstract class MemoryDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao

    companion object {
        @Volatile
        private var instance: MemoryDatabase? = null

        fun get(context: Context): MemoryDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MemoryDatabase::class.java,
                    "memory_vault.db"
                ).build().also { instance = it }
            }
    }
}
