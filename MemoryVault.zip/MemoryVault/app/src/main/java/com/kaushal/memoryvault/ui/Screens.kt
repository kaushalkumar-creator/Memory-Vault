package com.kaushal.memoryvault.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.kaushal.memoryvault.data.Memory
import com.kaushal.memoryvault.data.MemoryType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun typeIcon(type: String): ImageVector = when (type) {
    MemoryType.PROMPT -> Icons.Filled.AutoAwesome
    MemoryType.PHOTO -> Icons.Filled.Image
    MemoryType.VIDEO -> Icons.Filled.Videocam
    else -> Icons.Filled.Event
}

fun formatDate(millis: Long): String =
    SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(millis))

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Muted)
    }
}

@Composable
fun SectionHeader(title: String, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        if (actionText != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionText) }
        }
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Muted, textAlign = TextAlign.Center)
    }
}

@Composable
fun MemoryCard(memory: Memory, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Lavender),
                contentAlignment = Alignment.Center
            ) {
                Icon(typeIcon(memory.type), contentDescription = null, tint = Ink)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    memory.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val meta = listOf(MemoryType.label(memory.type), memory.eventDate)
                    .filter { it.isNotBlank() }
                    .joinToString(" · ")
                Text(meta, style = MaterialTheme.typography.labelSmall, color = Muted)
                if (memory.description.isNotBlank()) {
                    Text(
                        memory.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (memory.saved) {
                Icon(Icons.Filled.Favorite, contentDescription = "Saved", tint = Ink, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun HomeScreen(
    memories: List<Memory>,
    onSearch: () -> Unit,
    onSeeAll: () -> Unit,
    onOpen: (Memory) -> Unit
) {
    val recent = memories.take(5)
    val latestSaved = memories.filter { it.saved }.take(5)
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Memory Vault", "Keep the things worth remembering.") }
        item {
            Card(
                onClick = onSearch,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = Muted)
                    Spacer(Modifier.width(10.dp))
                    Text("Search your memories", color = Muted)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
        item { SectionHeader("Recent Memories", "See all", onSeeAll) }
        if (recent.isEmpty()) {
            item { EmptyState("No memories yet", "Open Library to store your first memory.") }
        }
        items(recent, key = { it.id }) { memory ->
            MemoryCard(memory) { onOpen(memory) }
        }
        item { SectionHeader("Latest Saved") }
        if (latestSaved.isEmpty()) {
            item { EmptyState("Nothing saved yet", "Open a memory and tap Save.") }
        }
        items(latestSaved, key = { "saved-${it.id}" }) { memory ->
            MemoryCard(memory) { onOpen(memory) }
        }
    }
}

@Composable
fun LibraryScreen(onCreate: (String) -> Unit) {
    val types = listOf(
        Triple(MemoryType.PROMPT, "Prompt", "Store prompts with reference images and notes."),
        Triple(MemoryType.PHOTO, "Photo", "Upload or store important photos with their details."),
        Triple(MemoryType.VIDEO, "Video", "Store videos, clips and editing references."),
        Triple(MemoryType.EVENT, "Event", "Save an event, date, time or anything outside the other categories.")
    )
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Library", "Choose what you want to store.") }
        items(types, key = { it.first }) { (type, title, description) ->
            Card(
                onClick = { onCreate(type) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Lavender),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(typeIcon(type), contentDescription = null, tint = Ink)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(description, style = MaterialTheme.typography.bodySmall, color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
fun SavedScreen(memories: List<Memory>, onOpen: (Memory) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Saved", "Your saved memories.") }
        if (memories.isEmpty()) {
            item { EmptyState("Nothing saved yet", "Open a memory and tap Save.") }
        }
        items(memories, key = { it.id }) { memory ->
            MemoryCard(memory) { onOpen(memory) }
        }
    }
}

@Composable
fun ProfileScreen(total: Int, saved: Int) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScreenHeader("Profile", "Your personal memory space.")
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = CardWhite)
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Ink),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Paper)
                }
                Text("Memory Vault", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("$total Memories", style = MaterialTheme.typography.bodyLarge)
                Text("$saved Saved", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
fun SearchScreen(
    memories: List<Memory>,
    recent: List<String>,
    onAddSearch: (String) -> Unit,
    onOpen: (Memory) -> Unit,
    onBack: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(query, memories) {
        val q = query.trim()
        if (q.isEmpty()) emptyList()
        else memories.filter { m ->
            listOf(m.title, m.description, MemoryType.label(m.type), m.eventDate, m.eventTime)
                .any { it.contains(q, ignoreCase = true) }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search your memories") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
        }
        Spacer(Modifier.height(16.dp))

        when {
            query.isBlank() -> {
                Text("Recent Searches", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                if (recent.isEmpty()) {
                    Text("Your recent searches will appear here.", color = Muted)
                } else {
                    recent.forEach { s ->
                        Text(
                            s,
                            modifier = Modifier.fillMaxWidth().clickable { query = s }.padding(vertical = 12.dp)
                        )
                    }
                }
            }
            results.isEmpty() -> EmptyState("No memories found", "Try another search.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(results, key = { it.id }) { memory ->
                    MemoryCard(memory) {
                        onAddSearch(query)
                        onOpen(memory)
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryFormScreen(type: String, onBack: () -> Unit, onSave: (Memory) -> Unit) {
    val context = LocalContext.current
    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf("") }
    var time by rememberSaveable { mutableStateOf("") }
    var mediaUri by rememberSaveable { mutableStateOf<String?>(null) }

    val mimeType = if (type == MemoryType.VIDEO) "video/*" else "image/*"
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: SecurityException) {
                // Some providers do not allow persistable grants; the URI still works for this session.
            }
            mediaUri = uri.toString()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("New ${MemoryType.label(type)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text(if (type == MemoryType.PROMPT) "Prompt title" else "Title") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = {
                Text(
                    when (type) {
                        MemoryType.PROMPT -> "Prompt / Notes"
                        MemoryType.EVENT -> "Event notes"
                        else -> "Details / notes"
                    }
                )
            },
            minLines = 4,
            modifier = Modifier.fillMaxWidth()
        )

        if (type == MemoryType.EVENT) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Time (HH:MM)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
            OutlinedButton(
                onClick = { picker.launch(arrayOf(mimeType)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (mediaUri == null) {
                        if (type == MemoryType.VIDEO) "Select video" else "Select image"
                    } else {
                        "Change selected file"
                    }
                )
            }
            if (mediaUri != null) {
                TextButton(onClick = { mediaUri = null }) { Text("Remove file") }
            }
        }

        Button(
            onClick = {
                onSave(
                    Memory(
                        type = type,
                        title = title.trim(),
                        description = description.trim(),
                        mediaUri = if (type == MemoryType.EVENT) null else mediaUri,
                        eventDate = date.trim(),
                        eventTime = time.trim()
                    )
                )
            },
            enabled = title.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("Save memory")
        }
    }
}

@Composable
fun MemoryDetailDialog(
    memory: Memory,
    onDismiss: () -> Unit,
    onToggleSave: () -> Unit,
    onDelete: () -> Unit,
    onOpenMedia: () -> Unit
) {
    var confirmDelete by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(22.dp), color = CardWhite, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(MemoryType.label(memory.type), style = MaterialTheme.typography.labelMedium, color = Muted)
                Text(
                    memory.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                if (memory.description.isNotBlank()) {
                    Text(
                        memory.description,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())
                    )
                }
                if (memory.eventDate.isNotBlank() || memory.eventTime.isNotBlank()) {
                    Text("${memory.eventDate} ${memory.eventTime}".trim(), style = MaterialTheme.typography.bodyMedium)
                }
                Text("Created ${formatDate(memory.createdAt)}", style = MaterialTheme.typography.labelSmall, color = Muted)

                if (memory.mediaUri != null) {
                    Button(
                        onClick = onOpenMedia,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (memory.type == MemoryType.VIDEO) "Open Video" else "Open Photo")
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onToggleSave, modifier = Modifier.weight(1f)) {
                        Icon(
                            if (memory.saved) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = null
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(if (memory.saved) "Unsave" else "Save")
                    }
                    OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Delete")
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close") }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete memory?") },
            text = { Text("This memory will be removed from Memory Vault.") },
            confirmButton = { TextButton(onClick = onDelete) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
